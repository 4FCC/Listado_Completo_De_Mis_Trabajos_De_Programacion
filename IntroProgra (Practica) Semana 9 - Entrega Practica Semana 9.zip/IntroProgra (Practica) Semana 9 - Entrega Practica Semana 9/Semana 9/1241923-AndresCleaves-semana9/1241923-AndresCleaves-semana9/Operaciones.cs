﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Variables




namespace Operaciones
{
    public class Operaciones
    {

        double Sumatoria;
        double Factorial;
        double TDM;
        double NumeroP;

        // Sumatoria

        


        // Factorial



        // Tabla de Multiplicacion



        // Numero Perfecto

        

    }

}
