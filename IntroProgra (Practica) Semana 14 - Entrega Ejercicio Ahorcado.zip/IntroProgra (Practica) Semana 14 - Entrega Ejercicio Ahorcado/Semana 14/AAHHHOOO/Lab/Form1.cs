using System;
using System.Windows.Forms;

namespace Lab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string palabra = textBox1.Text;

            foreach (char c in palabra)
            {
                MessageBox.Show("Caracter encontrado: " + c, "Notificacion de Caracteres", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string palabraBase = "COPA";

            if (textBox2.Text.Length != 1 || textBox3.Text.Length != 1 || textBox4.Text.Length != 1 || textBox5.Text.Length != 1)
            {
                MessageBox.Show("Debe ingresar solo un caracter en cada casilla.");
                return;
            }

            char[] posiciones = { textBox2.Text[0], textBox3.Text[0], textBox4.Text[0], textBox5.Text[0] };

            foreach (char c in posiciones)
            {
                if (!Char.IsLetter(c))
                {
                    MessageBox.Show("Debe ingresar una letra en cada casilla.");
                    return;
                }
            }

            string letrasIngresadas = new string(posiciones);

            if (palabraBase.Contains(letrasIngresadas))
            {
                MessageBox.Show("La palabra es correcta, est� contenida.");
            }
            else
            {
                MessageBox.Show("Error, la palabra no est� contenida.");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}