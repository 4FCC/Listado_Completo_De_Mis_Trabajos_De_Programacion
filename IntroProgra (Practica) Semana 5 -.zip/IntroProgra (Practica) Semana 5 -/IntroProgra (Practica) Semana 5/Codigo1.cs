using System;

namespace T4___E1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese 3 de las 4 variables para calcular la restante.");
            Console.WriteLine("1. Velocidad Final (Vf)");
            Console.WriteLine("2. Velocidad Inicial (Vo)");
            Console.WriteLine("3. Aceleración (a)");
            Console.WriteLine("4. Tiempo (t)");

            // Pedir al usuario que ingrese las variables
            Console.Write("Ingrese la variable 1: ");
            string var1Str = Console.ReadLine();
            Console.Write("Ingrese la variable 2: ");
            string var2Str = Console.ReadLine();
            Console.Write("Ingrese la variable 3: ");
            string var3Str = Console.ReadLine();

            // Convertir las variables ingresadas a números (si es posible)
            double var1, var2, var3;
            if (!double.TryParse(var1Str, out var1) || !double.TryParse(var2Str, out var2) || !double.TryParse(var3Str, out var3))
            {
                Console.WriteLine("Error: Debe ingresar valores numéricos válidos para 3 de las 4 variables.");
                Console.ReadLine();
                return;
            }

            // Verificar cuál variable falta por calcular
            double result;
            string resultVariable = "";
            if (var1 == 0)
            {
                result = var2 + (var3 * var1);
                resultVariable = "Velocidad Final (Vf)";
            }
            else if (var2 == 0)
            {
                result = var1 - (var3 * var2);
                resultVariable = "Velocidad Inicial (Vo)";
            }
            else if (var3 == 0)
            {
                result = (var1 - var2) / var3;
                resultVariable = "Aceleración (a)";
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar exactamente 3 de las 4 variables.");
                Console.ReadLine();
                return;
            }

            // Mostrar el resultado
            Console.WriteLine($"El valor de {resultVariable} es: {result}");
            Console.ReadLine();
        }
    }
}
